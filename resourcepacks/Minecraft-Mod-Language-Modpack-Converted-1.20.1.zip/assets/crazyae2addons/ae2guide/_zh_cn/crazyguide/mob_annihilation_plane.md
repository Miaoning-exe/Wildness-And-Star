---
navigation:
  parent: crazyae2addons_index.md
  title: 生物破坏面板
  icon: crazyae2addons:mob_annihilation_plane
categories:
  - Mob Storage
item_ids:
  - crazyae2addons:mob_annihilation_plane
---
# 生物破坏面板

生物破坏面板是一类特殊的线缆子部件，能够捕捉生物，并将其直接存入ME网络。它会瞬间移除站在它前方的生物，然后送入ME存储系统。

## 使用方法

1. **放置生物破坏面板**
2. **存储设施**
    - 确保网络可以存储“生物数据”（生物存储元件）。
3. **就这样了**

## 重要注意事项

- **只对真正的生物有效**：包括友好生物和敌对生物，但对玩家和非生物实体无效。